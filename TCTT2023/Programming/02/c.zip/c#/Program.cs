﻿using System.Diagnostics;
using CTF01;
using QuestPDF.Fluent;
using QuestPDF.Previewer;

var filePath = "CTF01.pdf";

//
//


//Process.Start("explorer.exe", filePath);


